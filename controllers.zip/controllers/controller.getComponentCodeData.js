const { getComponentCodeData } = require('../models/model.getComponentCodeData');

/**
 * Controller to get component details by cm_code and component_code using three-table approach
 */
async function getComponentCodeDataController(request, reply) {
  try {
    console.log('🔍 ===== GET COMPONENT CODE DATA API =====');
    
    const { cm_code, component_code } = request.body;
    
    console.log('📋 Request Parameters:');
    console.log('  - CM Code:', cm_code);
    console.log('  - Component Code:', component_code);

    // Validate required parameters
    if (!cm_code || cm_code.trim() === '') {
      return reply.code(400).send({
        success: false,
        message: 'cm_code is required'
      });
    }
    
    if (!component_code || component_code.trim() === '') {
      return reply.code(400).send({
        success: false,
        message: 'component_code is required'
      });
    }

    // Get component details and evidence by cm_code and component_code
    console.log('\n📊 === FETCHING DATA FROM DATABASE ===');
    const results = await getComponentCodeData(cm_code, component_code);
    
    console.log(`✅ Found ${results.length} results for CM: ${cm_code} and component_code: ${component_code}`);

    // Transform results to match the exact expected response structure
    const componentsWithEvidence = results.map(result => ({
      component_details: {
        id: result.component.id,
        component_code: result.component.component_code,
        component_description: result.component.component_description,
        material_type_id: result.component.material_type_id,
        component_valid_from: result.component.component_valid_from,
        component_valid_to: result.component.component_valid_to,
        component_material_group: result.component.component_material_group,
        component_quantity: result.component.component_quantity,
        component_uom_id: result.component.component_uom_id,
        component_base_quantity: result.component.component_base_quantity,
        component_base_uom_id: result.component.component_base_uom_id,
        percent_w_w: result.component.percent_w_w,
        component_packaging_type_id: result.component.component_packaging_type_id,
        component_packaging_material: result.component.component_packaging_material,
        component_unit_weight: result.component.component_unit_weight,
        weight_unit_measure_id: result.component.weight_unit_measure_id,
        percent_mechanical_pcr_content: result.component.percent_mechanical_pcr_content,
        percent_mechanical_pir_content: result.component.percent_mechanical_pir_content,
        percent_chemical_recycled_content: result.component.percent_chemical_recycled_content,
        percent_bio_sourced: result.component.percent_bio_sourced,
        material_structure_multimaterials: result.component.material_structure_multimaterials,
        component_packaging_color_opacity: result.component.component_packaging_color_opacity,
        component_packaging_level_id: result.component.component_packaging_level_id,
        component_dimensions: result.component.component_dimensions
      },
      evidence_files: result.evidence.map(evidence => ({
        id: evidence.id,
        category: evidence.category,
        evidence_file_name: evidence.evidence_file_name,
        evidence_file_url: evidence.evidence_file_url
      }))
    }));

    const responseData = {
      success: true,
      data: {
        components_with_evidence: componentsWithEvidence
      }
    };

    console.log('\n📤 === API RESPONSE ===');
    console.log('Status Code: 200');
    console.log('Response Body:');
    console.log(JSON.stringify(responseData, null, 2));

    reply.code(200).send(responseData);

  } catch (error) {
    console.error('❌ Error in getComponentCodeDataController:', error);
    reply.code(500).send({
      success: false,
      message: 'Failed to fetch component data',
      error: error.message
    });
  }
}

module.exports = { getComponentCodeDataController }; 